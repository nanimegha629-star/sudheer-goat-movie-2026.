# GOAT — Sudheer Cricket Challenge

A mobile-first HTML5 cricket game designed for Vercel.

## Replace the character photos
Put these files inside `assets/`:

- `sudheer.jpg` — Sudheer hero/cricketer
- `villain1.jpg` — villain 1
- `villain2.jpg` — villain 2
- `villain3.jpg` — optional villain 3

The game already works without photos using fallback player silhouettes.

## Deploy on Vercel
1. Upload this entire folder to GitHub.
2. In Vercel, import the GitHub repository.
3. Framework preset: **Other** (or leave automatic detection).
4. Build command: **leave empty**.
5. Output directory: **leave empty**.
6. Deploy.

The important file is `index.html` at the repository root.

## Gameplay
- 12 balls
- 2 wickets allowed
- Tap LEFT / POWER / RIGHT
- Desktop: A / Space / D
- Target: 25+ runs without losing both wickets

## Next upgrade
The current version is a clean playable foundation. Character photos, crowd art, stadium branding, bowling/fielding animations, leaderboards and online multiplayer can be added as the next layer.
